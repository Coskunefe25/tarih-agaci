// --- OTOMATİK İÇERİK ÜRETİCİ FONKSİYONU ---
async function yapayZekaIleIcerikOlustur(konuBasligi, kategori) {
    const prompt = `
    Sen uzman bir tarih öğretmenisin. Konumuz: "${konuBasligi}".
    Bu konu hakkında detaylı, sürükleyici ve öğretici bir ders içeriği hazırla.
    
    ÇOK ÖNEMLİ KURALLAR:
    1. Çıktı sadece HTML formatında olacak. (<html> veya <body> etiketleri KULLANMA, sadece içerik divleri).
    2. Sitenin tasarımına uyması için şu CSS sınıflarını kullan:
       - Başlıklar için: <h4 class="text-primary cinzel-font mt-3"><i class="fa-solid fa-star me-2"></i> BAŞLIK </h4>
       - Vurgulu kutular için: <div class="alert alert-info mt-3 border-start border-5 border-primary"> ... </div>
       - Önemli notlar için: <div class="p-3 mb-3 bg-light border-start border-4 border-danger fst-italic text-muted"> ... </div>
    3. FontAwesome ikonlarını (fa-solid fa-...) bolca kullan.
    4. İçeriği 3-4 ana başlık altında topla.
    5. Asla "İşte hazırladığım içerik" gibi giriş cümleleri kurma, direkt konuya gir.
    6. Dil Türkçe ve epik bir anlatım tarzında olsun.
    `;

    try {
        const result = await model.generateContent(prompt);
        const response = await result.response;
        return response.text();
    } catch (err) {
        console.error("AI İçerik Üretme Hatası:", err);
        return null;
    }
}

const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const db = require('./db'); 
const { GoogleGenerativeAI } = require("@google/generative-ai");

// SENİN API KEY'İN (Test dosyasındaki çalışan key)
const genAI = new GoogleGenerativeAI("AIzaSyD6gUuqgEBLTDMYNfsro-8Iuy-r384swQw");

// GÜNCELLEME: Senin hesabında açık olan 'gemini-2.5-flash' modelini seçtim.
const model = genAI.getGenerativeModel({ model: "gemini-2.5-flash" });

const app = express();

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

app.use(express.static(path.join(__dirname, 'public')));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// --- ANASAYFA ---
app.get('/', async (req, res) => {
    try {
        const [liderler] = await db.execute('SELECT * FROM liderler ORDER BY sira_no ASC');
        const [devletler] = await db.execute('SELECT * FROM devletler ORDER BY sira_no ASC');
        const [kategoriler] = await db.execute('SELECT * FROM kategoriler');
        const [kategoriOgeleri] = await db.execute('SELECT * FROM kategori_ogeleri ORDER BY sira_no ASC');
        const [top100] = await db.execute('SELECT kadi, ad, soyad, puan FROM kullanicilar ORDER BY puan DESC LIMIT 100');
        
        res.render('index', { 
            baslik: "Tarih Ağacı",
            liderler: liderler || [],
            devletler: devletler || [],
            kategoriler: kategoriler || [],
            kategoriOgeleri: kategoriOgeleri || [],
            enIyiler: top100 || []
        });
    } catch (err) {
        console.log(err);
        res.status(500).send("Veritabanı hatası!");
    }
});

// --- ADMIN PANELI ---
app.get('/admin', async (req, res) => {
    try {
        const [kategoriler] = await db.execute('SELECT * FROM kategoriler');
        const [liderler] = await db.execute('SELECT * FROM liderler ORDER BY id DESC');
        const [devletler] = await db.execute('SELECT * FROM devletler ORDER BY id DESC');
        const [ogeler] = await db.execute('SELECT * FROM kategori_ogeleri ORDER BY id DESC');
        const [kullanicilar] = await db.execute('SELECT * FROM kullanicilar ORDER BY id DESC');

        res.render('admin', { 
            kategoriler: kategoriler,
            liderler: liderler,
            devletler: devletler,
            ogeler: ogeler,
            kullanicilar: kullanicilar
        });
    } catch (err) {
        res.send("Admin paneli hatası: " + err.message);
    }
});

// --- İÇERİK ÜRETME API ---
app.post('/api/icerik-uret', async (req, res) => {
    const { baslik, kategori } = req.body;
    console.log(`AI İçerik Üretiyor... Konu: ${baslik}`);

    try {
        const uretilenIcerik = await yapayZekaIleIcerikOlustur(baslik, kategori);
        if (uretilenIcerik) {
            res.json({ success: true, icerik: uretilenIcerik });
        } else {
            res.status(500).json({ success: false, message: "İçerik boş döndü." });
        }
    } catch (error) {
        console.error("Route Hatası:", error);
        res.status(500).json({ success: false, error: error.message });
    }
});

// --- EKLEME İŞLEMLERİ (BOŞ DETAY KONTROLÜ İLE) ---
app.post('/admin/lider-ekle', async (req, res) => {
    let { ad, donem, detay, sira_no } = req.body;
    if (!detay || detay.trim() === "") detay = "İçerik hazırlanıyor...";
    try {
        await db.execute('INSERT INTO liderler (ad, donem, detay, sira_no) VALUES (?, ?, ?, ?)', [ad, donem, detay, sira_no || 99]);
        res.redirect('/admin?mesaj=basarili');
    } catch (err) { res.send('Hata: ' + err.message); }
});

app.post('/admin/devlet-ekle', async (req, res) => {
    let { ad, kurulus, baskent, detay, sira_no } = req.body;
    if (!detay || detay.trim() === "") detay = "İçerik hazırlanıyor...";
    try {
        await db.execute('INSERT INTO devletler (ad, kurulus, baskent, detay, sira_no) VALUES (?, ?, ?, ?, ?)', [ad, kurulus, baskent, detay, sira_no || 99]);
        res.redirect('/admin?mesaj=basarili');
    } catch (err) { res.send('Hata: ' + err.message); }
});

app.post('/admin/oge-ekle', async (req, res) => {
    let { kategori_kod, baslik, aciklama, detay, sira_no } = req.body;
    if (!detay || detay.trim() === "") detay = "İçerik hazırlanıyor...";
    try {
        await db.execute('INSERT INTO kategori_ogeleri (kategori_kod, baslik, aciklama, detay, sira_no) VALUES (?, ?, ?, ?, ?)', [kategori_kod, baslik, aciklama, detay, sira_no || 99]);
        res.redirect('/admin?mesaj=basarili');
    } catch (err) { res.send('Hata: ' + err.message); }
});

app.post('/admin/soru-ekle', async (req, res) => {
    const { konu_tipi, konu_id, soru_metni, sik_a, sik_b, sik_c, sik_d, dogru_cevap } = req.body;
    try {
        await db.execute(
            'INSERT INTO konu_quizleri (konu_tipi, konu_id, soru_metni, sik_a, sik_b, sik_c, sik_d, dogru_cevap) VALUES (?, ?, ?, ?, ?, ?, ?, ?)', 
            [konu_tipi, konu_id, soru_metni, sik_a, sik_b, sik_c, sik_d, dogru_cevap]
        );
        res.redirect('/admin?mesaj=soru-eklendi');
    } catch (err) { res.send('Soru ekleme hatası: ' + err.message); }
});

app.post('/admin/konu-guncelle', async (req, res) => {
    const { konu_tipi, konu_id, yeni_detay } = req.body;
    try {
        let sql = '';
        if (konu_tipi === 'lider') sql = 'UPDATE liderler SET detay = ? WHERE id = ?';
        else if (konu_tipi === 'devlet') sql = 'UPDATE devletler SET detay = ? WHERE id = ?';
        else sql = 'UPDATE kategori_ogeleri SET detay = ? WHERE id = ?';
        await db.execute(sql, [yeni_detay, konu_id]);
        res.redirect('/admin?mesaj=konu-guncellendi');
    } catch (err) { res.send('Güncelleme hatası: ' + err.message); }
});

// --- SİLME İŞLEMLERİ ---
app.post('/admin/sil/lider', async (req, res) => { try { await db.execute('DELETE FROM liderler WHERE id = ?', [req.body.id]); res.redirect('/admin?mesaj=silindi'); } catch (err) { res.send(err.message); } });
app.post('/admin/sil/devlet', async (req, res) => { try { await db.execute('DELETE FROM devletler WHERE id = ?', [req.body.id]); res.redirect('/admin?mesaj=silindi'); } catch (err) { res.send(err.message); } });
app.post('/admin/sil/oge', async (req, res) => { try { await db.execute('DELETE FROM kategori_ogeleri WHERE id = ?', [req.body.id]); res.redirect('/admin?mesaj=silindi'); } catch (err) { res.send(err.message); } });
app.post('/admin/sil/kullanici', async (req, res) => {
    try {
        await db.execute('DELETE FROM kullanici_ilerleme WHERE kullanici_id = ?', [req.body.id]);
        await db.execute('DELETE FROM kullanicilar WHERE id = ?', [req.body.id]);
        res.redirect('/admin?mesaj=kullanici-silindi');
    } catch (err) { res.send(err.message); }
});

// --- API'LER ---
app.get('/api/ilerleme/:kullaniciId', async (req, res) => {
    try {
        const [rows] = await db.execute('SELECT * FROM kullanici_ilerleme WHERE kullanici_id = ?', [req.params.kullaniciId]);
        res.json(rows);
    } catch (err) { res.status(500).json({ error: err.message }); }
});

app.get('/api/quiz/:konuTipi/:konuId', async (req, res) => {
    try {
        const [rows] = await db.execute('SELECT * FROM konu_quizleri WHERE konu_tipi = ? AND konu_id = ?', [req.params.konuTipi, req.params.konuId]);
        res.json(rows);
    } catch (err) { res.status(500).json({ error: err.message }); }
});

app.post('/api/tamamla', async (req, res) => {
    const { kullaniciId, tip, id, puan } = req.body;
    try {
        await db.execute('INSERT IGNORE INTO kullanici_ilerleme (kullanici_id, konu_tipi, konu_id) VALUES (?, ?, ?)', [kullaniciId, tip, id]);
        if(puan > 0) await db.execute('UPDATE kullanicilar SET puan = puan + ? WHERE id = ?', [puan, kullaniciId]);
        res.json({ success: true });
    } catch (err) { res.status(500).json({ error: err.message }); }
});

app.post('/api/puan-ekle', async (req, res) => {
    try {
        await db.execute('UPDATE kullanicilar SET puan = puan + ? WHERE id = ?', [req.body.puan, req.body.kullaniciId]);
        res.json({ success: true });
    } catch (err) { res.status(500).json({ error: err.message }); }
});

app.get('/api/liderlik-verisi', async (req, res) => {
    try {
        const [top100] = await db.execute('SELECT kadi, ad, soyad, puan FROM kullanicilar ORDER BY puan DESC LIMIT 100');
        res.json(top100);
    } catch (err) { res.status(500).json({ error: err.message }); }
});

app.post('/api/kayit', async (req, res) => {
    const { ad, soyad, kadi, eposta, sifre } = req.body;
    try {
        await db.execute('INSERT INTO kullanicilar (ad, soyad, kadi, eposta, sifre) VALUES (?, ?, ?, ?, ?)', [ad, soyad, kadi, eposta, sifre]);
        res.json({ message: "Kayıt başarılı!" });
    } catch (err) { res.status(500).json({ error: err.message }); }
});

app.post('/api/giris', async (req, res) => {
    try {
        const [users] = await db.execute('SELECT * FROM kullanicilar WHERE kadi = ? AND sifre = ?', [req.body.kadi, req.body.sifre]);
        if (users.length > 0) res.json({ success: true, user: users[0] });
        else res.status(401).json({ success: false, message: "Hatalı kullanıcı adı veya şifre!" });
    } catch (err) { res.status(500).json({ success: false, message: "Sunucu hatası!" }); }
});

// --- ÖZEL ROTA: TIKLAYINCA OLUŞTUR VE GETİR ---
app.post('/api/detay-getir-veya-olustur', async (req, res) => {
    const { id, tip } = req.body; 
    try {
        let tabloAdi = '';
        if (tip === 'lider') tabloAdi = 'liderler';
        else if (tip === 'devlet') tabloAdi = 'devletler';
        else tabloAdi = 'kategori_ogeleri';

        const [kayitlar] = await db.execute(`SELECT * FROM ${tabloAdi} WHERE id = ?`, [id]);
        if (kayitlar.length === 0) return res.status(404).json({ error: "Kayıt bulunamadı." });

        let kayit = kayitlar[0];
        // Detay doluysa direkt gönder
        if (kayit.detay && kayit.detay.length > 50) {
            return res.json({ icerik: kayit.detay });
        }

        console.log("Detay boş, Yapay Zeka oluşturuyor...");
        const yeniIcerik = await yapayZekaIleIcerikOlustur(kayit.ad || kayit.baslik, tip);

        if (!yeniIcerik) return res.status(500).json({ error: "İçerik oluşturulamadı." });

        await db.execute(`UPDATE ${tabloAdi} SET detay = ? WHERE id = ?`, [yeniIcerik, id]);
        res.json({ icerik: yeniIcerik });

    } catch (err) {
        console.error("Detay Getirme Hatası:", err);
        res.status(500).json({ error: err.message });
    }
});

// --- CHAT BOT API ---
app.post('/api/chat-bot', async (req, res) => {
    try {
        const chat = model.startChat({
            history: [
                { role: "user", parts: [{ text: "Sen 'Tarihçi'sin. Samimi konuş, sadece tarih sorularını cevapla." }] },
                { role: "model", parts: [{ text: "Tamamdır reis, ben Tarihçi. Sorularını bekliyorum." }] },
            ],
        });
        const result = await chat.sendMessage(req.body.mesaj);
        res.json({ cevap: (await result.response).text() });
    } catch (err) {
        console.error("AI Hatası:", err);
        res.status(500).json({ error: "Şu an bağlantı kuramıyorum.", detay: err.message });
    }
});

const PORT = 3000;
app.listen(PORT, () => { console.log(`Sunucu http://localhost:${PORT} adresinde çalışıyor...`); });