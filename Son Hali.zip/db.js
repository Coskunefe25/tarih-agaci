const mysql = require('mysql2');

// Veritabanı ayarlarını kendine göre kontrol et
const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '12345',  // Senin şifren
    database: 'tarih_agaci'
});

connection.connect((err) => {
    if (err) {
        console.error('❌ Veritabanı bağlantı hatası: ', err);
        return;
    }
    console.log('✅ MySQL veritabanına başarıyla bağlandı!');
});

module.exports = connection.promise();